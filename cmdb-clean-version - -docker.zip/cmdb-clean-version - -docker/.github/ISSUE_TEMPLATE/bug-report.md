---
name: "🐛 Bug Report"
about: Report a reproducible bug or regression.
title: 'Bug: '
---

<!--
  Spug 版本信息可以在 系统管理/系统设置/关于 中查看，请填写 Spug 版本信息。
-->

Spug 版本:

## 问题重现步骤

1.
2.

## 报错/问题截图


## 期望的结果

