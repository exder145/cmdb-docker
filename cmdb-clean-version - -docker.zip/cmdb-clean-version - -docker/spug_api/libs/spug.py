class Notification:
       def __init__(self, *args, **kwargs):
        pass
       
       def dispatch(self, *args, **kwargs):
        pass